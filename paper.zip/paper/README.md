# Paper draft — FiscalQA Pro

LaTeX source of the workshop paper accompanying this repo.

## Structure

```
paper/
├── main.tex                  # entry point, \input's each section
├── references.bib            # bibliography
├── sections/
│   ├── 00_abstract.tex
│   ├── 01_introduction.tex
│   ├── 02_related_work.tex
│   ├── 03_corpus.tex
│   ├── 04_benchmark.tex
│   ├── 05_experiments.tex
│   ├── 06_results.tex
│   ├── 07_limitations.tex
│   └── 08_conclusion.tex
└── figures/                  # to be added
```

## Target venue

To confirm with Laurent. Candidates:
- **NLLP @ EMNLP 2026** (short or long paper) — most natural fit, ML+law audience
- **JURIX 2026** — legal AI specialists, more law-focused
- **ACL Findings 2026 — legal track** — broader NLP audience
- **ICAIL 2026** — applied legal AI

Final choice drives format (4p short / 8p long), style file, and bib style.

## Build instructions

Once a target style is chosen, drop the corresponding `.sty` files (ACL provides them at https://github.com/acl-org/acl-style-files) into this directory and:

```bash
cd paper
pdflatex main
bibtex main
pdflatex main
pdflatex main
```

Or use Overleaf: upload the `paper/` directory as a project.

## Status (as of 2026-05-14)

| Section | Status | Notes |
|---|---|---|
| Abstract | 🟡 first draft | numerical placeholders to fill |
| Introduction | 🟡 first draft | done |
| Related Work | 🟡 first draft | add 1-2 NER references |
| Corpus | ✅ ready for review | numbers verified |
| Benchmark | 🟡 first draft | N pending question curation |
| Experiments | 🟡 design done | results pending |
| Results | 🔴 placeholders | filled as experiments complete |
| Limitations | 🟡 first draft | done |
| Conclusion | 🟡 first draft | done |

## TODOs (search the source for `\todo{...}`)

The `\todo{}` macro highlights all open numerical placeholders, missing references, and pending decisions. Render the draft in PDF to see them in red.
